README – Instrucciones de ejecución (Proyecto APIs Demoblaze)

Requisitos:
- Java 11 o superior instalado y configurado en PATH.
- Maven instalado.

Estructura del proyecto:
Proyecto-APIs-Demoblaze/
├── src/test/java/demoblaze/
│   ├── signup.feature
│   ├── login.feature
│   └── data/
│       ├── usuarios.csv
│       └── usuarios.json
├── karate-config.js
├── pom.xml
├── readme.txt
└── conclusiones.txt

Ejecutar los tests:
1. Abrir terminal en la raíz del proyecto (donde está pom.xml).
2. Ejecutar:
   mvn clean test

Reportes:
- Karate genera reportes en: target/karate-reports/
- Abrir target/karate-reports/karate-summary.html en el navegador.

Notas:
- Los feature usan 'classpath:demoblaze/data/...' para leer los archivos CSV/JSON.
- Si la API cambia su respuesta textual, ajustar las aserciones en los feature.
