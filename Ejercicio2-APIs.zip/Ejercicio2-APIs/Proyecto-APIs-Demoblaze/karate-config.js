function fn() {
  var config = {
    baseUrl: 'https://api.demoblaze.com'
  };
  return config;
}
